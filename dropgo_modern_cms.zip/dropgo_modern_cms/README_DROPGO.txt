SITE DROPGO MODERNE + BACKOFFICE

1) Mets ce dossier sur GitHub.
2) Dans Netlify : Add new site > Import from GitHub.
3) Active Netlify Identity : Site configuration > Identity > Enable.
4) Active Git Gateway : Identity > Services > Git Gateway > Enable.
5) Va sur : https://ton-site.netlify.app/admin/

IMPORTANT
Le backoffice /admin fonctionne seulement avec GitHub + Netlify Identity.
Si tu glisses simplement le dossier dans Netlify, le site s'affiche, mais l'admin ne pourra pas enregistrer.

MODIFIER RAPIDEMENT SANS ADMIN
Les concerts visibles sont dans events.js.
Tu peux changer les textes entre guillemets.

IMAGES
Remplace les fichiers dans assets/img par tes vraies affiches.
Garde les mêmes noms pour que tout se mette à jour automatiquement.
